# COM S 319 Homework 3

## by Akmal Fahmi Mohamad Rafie, NETID: fahmi

### Task 1

To run Task 1, simply click on `snake.html` in the `/src/task1/` directory

### Task 2

To compile and run Task 2, simply type `node hw3.js` provided that the working directory is in the `/src/task2/` directory provided that **Node.js** is installed
