# README

## Compiling

1. Using a command line interface, navigate to the HW4 folder which contains the `src` folder, and this `README.md file`
2. Run `npm install`

## Running the program

1. Run `npm run build`
2. Open `index.html` inside the `public` folder
