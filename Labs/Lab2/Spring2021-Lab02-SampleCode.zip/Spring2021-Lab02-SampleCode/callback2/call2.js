function alertMessage(err,folderName ,data){
}

var lib=require('./myLib')
lib.dirSorted('folder',alertMessage);
lib.dirSorted('folder-2',alertMessage);
