var rs = require('readline-sync');

var fBinaryNum1 = rs.question('1st Number in Binary: ');
var fBinaryNum2 = rs.question('2nd Number in Binary: ');
var action = rs.question('Enter the action{+,-,*,/,%,&,|,~}');
