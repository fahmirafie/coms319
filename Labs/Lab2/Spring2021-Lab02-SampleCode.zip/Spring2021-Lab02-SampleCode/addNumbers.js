var sum = 0;
var i;
